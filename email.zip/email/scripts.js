// Mock inbox data
const inboxEmails = [
    { from: "friend@example.com", subject: "Catch up soon?", date: "Nov 1" },
    { from: "newsletter@company.com", subject: "Latest updates", date: "Oct 28" },
    { from: "team@workplace.com", subject: "Project review", date: "Oct 25" }
  ];
  
  // Populate inbox with sample emails
  function populateInbox() {
    const emailList = document.getElementById('email-list');
    inboxEmails.forEach(email => {
      const emailItem = document.createElement('li');
      emailItem.innerHTML = `<strong>${email.from}</strong> - ${email.subject} <span>${email.date}</span>`;
      emailList.appendChild(emailItem);
    });
  }
  
  // Show the compose email modal
  function showCompose() {
    document.getElementById('compose-modal').style.display = 'block';
  }
  
  // Close the compose email modal
  function closeCompose() {
    document.getElementById('compose-modal').style.display = 'none';
  }
  
  // Mock email send functionality
  function sendEmail() {
    alert("Email sent!");
    closeCompose();
  }
  