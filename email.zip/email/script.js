// script.js

let generatedEmails = [];  // Stores generated emails
let generatedPasswords = [];  // Stores generated passwords

// Generate a random password of specified length
function generateRandomPassword(length = 12) {
  const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789!@#$%^&*()_+-=';
  let password = '';
  for (let i = 0; i < length; i++) {
    const randomIndex = Math.floor(Math.random() * characters.length);
    password += characters[randomIndex];
  }
  return password;
}

// Process CSV file and generate email-password pairs
function processCSV() {
  const fileInput = document.getElementById('csvFile');
  const file = fileInput.files[0];

  if (!file) {
    alert('Please upload a CSV file.');
    return;
  }

  const reader = new FileReader();
  reader.onload = function(event) {
    const csvData = event.target.result;
    const firstNames = parseCSV(csvData);

    const emailData = generateEmailsAndPasswords(firstNames);
    exportToExcel(emailData); // Export data as an Excel file
  };

  reader.readAsText(file);
}

// Parse CSV data to extract first names
function parseCSV(csvData) {
  const rows = csvData.split('\n');
  const firstNames = [];

  for (let i = 1; i < rows.length; i++) { // Skip header row
    const cells = rows[i].split(',');
    const firstName = cells[0].trim();
    if (firstName) firstNames.push(firstName);
  }

  return firstNames;
}

// Generate email and password pairs from first names
function generateEmailsAndPasswords(firstNames) {
  const emailData = [];
  for (const firstName of firstNames) {
    const email = `${firstName.toLowerCase().replace(/\s+/g, '.')}@gmail.com`;
    const password = generateRandomPassword();

    generatedEmails.push(email);
    generatedPasswords.push(password);

    emailData.push({ 'First Name': firstName, 'Generated Email': email, 'Generated Password': password });
  }
  return emailData;
}

// Export generated data to an Excel file
function exportToExcel(data) {
  const ws = XLSX.utils.json_to_sheet(data);
  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, ws, 'Emails');
  XLSX.writeFile(wb, 'Generated_Emails.xlsx');
}

// Display login page
function showLoginPage() {
  document.querySelector('.container').style.display = 'none';
  document.getElementById('loginPage').style.display = 'block';
}

// Validate login credentials
function validateLogin() {
  const email = document.getElementById('loginEmail').value.trim().toLowerCase();
  const password = document.getElementById('loginPassword').value.trim();

  const emailIndex = generatedEmails.indexOf(email);
  
  if (emailIndex === -1 || generatedPasswords[emailIndex] !== password) {
    document.getElementById('loginMessage').textContent = 'Invalid email or password';
  } else {
    window.location.href = 'gmail-like-page.html';
  }
}

// Return to home page from login
function goBack() {
  document.querySelector('.container').style.display = 'block';
  document.getElementById('loginPage').style.display = 'none';
}
